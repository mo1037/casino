# KlassenQuest

Interaktive Klassen-Lautstärkeanzeige mit Coins, Pack-Opening und Sammelkarten.

## Veröffentlichen über GitHub Pages

1. Erstelle ein öffentliches GitHub-Repository namens `klassenquest`.
2. Lade die Datei `index.html` in das Hauptverzeichnis des Repositories hoch und committe sie.
3. Öffne **Settings → Pages**.
4. Wähle unter **Build and deployment**: **Deploy from a branch**, Branch **main**, Folder **/(root)** und speichere.
5. Die Website ist nach der Veröffentlichung unter `https://DEIN-BENUTZERNAME.github.io/klassenquest/` erreichbar.

## Hinweise

- Für die Mikrofonmessung ist HTTPS und die Erlaubnis des Browsers erforderlich.
- Coins, Karten und Einstellungen liegen ausschließlich im lokalen Browser-Speicher. Es gibt keine Konten oder Synchronisierung zwischen Geräten.
- Der Lehrer-PIN ist nur eine lokale Bedienungssperre und kein sicherer Zugriffsschutz. Standard: `1234`; nach dem ersten Start ändern.
- Belohnungen sollten vor Einlösung von der Lehrkraft genehmigt werden.
- Audio wird nicht aufgenommen oder an einen Server gesendet.
